import * as React from 'react';
import * as ReactDOM from 'react-dom';
import App from './Components/App';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter} from 'react-router-dom';
import './index.css';


ReactDOM.render(  <BrowserRouter><App /></BrowserRouter>, document.getElementById('root'));
