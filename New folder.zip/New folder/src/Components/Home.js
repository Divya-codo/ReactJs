import React from 'react';

function Home(props) {
    return (
        <div className="jumbotron">
            <h1 className="display-3">Shopping Cart</h1>
            {/* <p className="lead">More than 2 crore products</p> */}
            <hr className="my-1" />
            <p>Welcome to shopping cart.</p>
            <p className="lead">
                <a className="btn btn-primary btn-lg" href="/login/register" role="button">SignUp </a>&nbsp;&nbsp;&nbsp;
                <a className="btn btn-primary btn-lg" href="/login" role="button">Login</a>
            </p>
        </div>
    );
}

export default Home;