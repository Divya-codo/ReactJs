import React from 'react';
function Login(props) {

    return (
        <div className="jumbotron">
            <h1 className="display-2">Login page</h1>
            <br/>
            <div class="form-inline">
          <label for="Username">Username: </label>
            <input type="text" name="title" id="title" className="text" />
            <small id="UsernameHelp" class="text-muted">
             Please provide your full name.
            </small>
            </div>
            <br/>
            <div class="form-inline">
            <label for="Password">Password: </label>
            <input type="text" name="title" id="title" className="text" />
            <small id="PasswordHelp" class="text-muted">
             Please provide your Password.

            </small>
            </div>
            <br />
     <th><button type=" btn btn-danger">Submit  </button></th> 
     {/* <th><button type=" btn btn-danger">Register  </button></th> &nbsp; */}

    <th> <a className="btn btn-primary btn-lg" href="/" role="button">Back  </a> </th>
  </div>
    );
}
export default Login;