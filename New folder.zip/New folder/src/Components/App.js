import React from 'react';
import { Route } from 'react-router-dom';
import Navbar from './Navbar';
import Login from '../Components/Login';
import Register from '../Components/Register';
import Home from '../Components/Home';

function App(props) {
  return (
    <div>
      <Navbar />
<div className="container my-4">
    
        <Route path="/" exact component={Home} />
        <Route path="/login" exact component={Login} />
        <Route path="/login/register" exact component={Register} />
    </div>
      </div>
  );
}

export default App;








            