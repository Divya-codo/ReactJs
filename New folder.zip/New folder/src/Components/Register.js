import React, { Component } from 'react';

class Register extends Component {
    documentData;
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
    this.state = {
        values: {
            fn: '',
            ln:'',
            email:'',
            pw:''
        },
    
        errors: {
            fn: [],
            ln:[],
            email:[],
            pw:[]
        },
        wasValidated: false
    };
}

    fnRef = React.createRef();
    lnRef = React.createRef();
    emailRef = React.createRef();
    pwRef = React.createRef();
    
    validate = () => 
    {
        const errors = {
            fn: [],
           ln: [],
            email: [],
            pw: []
        };

        if( this.fnRef.current.value === '' ) {
            errors.fn.push( 'please enter your first name' );
        }

        if( this.lnRef.current.value === '' ) {
            errors.ln.push( 'please enter your last name' );
        }


        if( this.emailRef.current.value.length < 3 || this.emailRef.current.value.length > 20 ) {
            errors.email.push( 'please enter valid email Id' );
        }

     
        if( this.pwRef.current.value.length < 20 ) {
            errors.pw.push( 'please enter your password' );
        }

        this.setState({
            ...this.state,
            errors: errors,
            wasValidated: true
        });
    }
    
    isValid = () => {
        const { fn, ln, email, pw } = this.state.errors;
        
        return fn.length === 0 && ln.length === 0 && email.length === 0 && pw.length === 0;
    }
handleChange= (e)=> {this.setState({[e.target.name]:e.target.value})}

    // on form submit...
 handleFormSubmit(e)  
  {  e.preventDefault()
       localStorage.setItem('document',JSON.stringify(this.state));
 }


    // React Life Cycle
componentDidMount() {
        this.documentData = JSON.parse(localStorage.getItem('document'));     
        if (localStorage.getItem('document')) {
            this.setState({
                fn: this.documentData.fn,
                ln: this.documentData.ln,
               email: this.documentData.email,
               pw: this.documentData.pw
        })
    } 
    else {
        this.setState({
            fn: '',
            ln: '',
            email: '',
            pw:''
        })
    }

}
    
    
    
    render() {
    return (

        
        <div className="jumbotron">
            <div className ="container">  
             <form onSubmit={this.handleFormSubmit}>
            <h1 className="display-3">Register Page</h1>
             <br/>

     <form className={`form-horizontal ${this.state.wasValidated ? 'was-validated' : ''}` } 
                  onSubmit={this.handleFormSubmit}></form>
                    {/* b4-form-group */}
                    <div class="form-group">
                        <label for="fn">First Name</label>
                        <input type="text" name="fn" id="fn" 
                        class={`form-control ${this.state.errors.fn.length === 0 ? `is-valid` : `is-invalid`}`} 
                        placeholder="" aria-describedby="fnHelp" ref={this.fnRef}  onSubmit={this.handleChange}/>
                  <small id="fnHelp" class="text-muted">
             Please provide your first name.
            </small>
            <div className="invalid-feedback">
             {this.state.errors.fn.map( error => <div>{error}</div>)}
                        </div>
                    </div>
                     <br/>
      <form className={`form-horizontal ${this.state.wasValidated ? 'was-validated' : ''}`} 
                 onSubmit={this.handleFormSubmit}></form>
                    {/* b4-form-group */}
                    <div class="form-group">
                        <label for="ln">Last Name</label>
                        <input type="text" name="ln" id="ln" 
                        class={`form-control ${this.state.errors.ln.length === 0 ? `is-valid` : `is-invalid`}`} 
                        placeholder="" aria-describedby="lnHelp" ref={this.lnRef}  onSubmit={this.handleChange}/>
                  <small id="lnHelp" class="text-muted">
             Please provide your last name.
            </small>
            <div className="invalid-feedback">
             {this.state.errors.ln.map( error => <div>{error}</div>)}
                        </div>
                    </div>
            <br />
      <form className={`form-horizontal ${this.state.wasValidated ? 'was-validated' : ''}`} 
                 onSubmit={this.handleFormSubmit} ></form>
                    {/* b4-form-group */}
                    <div class="form-group">
                        <label for="email">EmailId</label>
                        <input type="text" name="email" id="email" 
                        class={`form-control ${this.state.errors.email.length === 0 ? `is-valid` : `is-invalid`}`} 
                        placeholder="" aria-describedby="emailHelp" ref={this.emailRef}  onSubmit={this.handleChange} />
                  <small id="emailHelp" class="text-muted">
             Please provide your email id.
            </small>
            <div className="invalid-feedback">
             {this.state.errors.email.map( error => <div>{error}</div>)}
                        </div>
                    </div>
            <br />
      <form className={`form-horizontal ${this.state.wasValidated ? 'was-validated' : ''}`} 
                  onSubmit={this.handleFormSubmit}></form>
                    {/* b4-form-group */}
                    <div class="form-group">
                        <label for="pw">Password</label>
                        <input type="password" name="pw" id="pw" 
                        class={`form-control ${this.state.errors.pw.length === 0 ? `is-valid` : `is-invalid`}`} 
                        placeholder="" aria-describedby="pwHelp" ref={this.pwRef}  onSubmit={this.handleChange} />
                  <small id="pwHelp" class="text-muted">
             Please provide your password.
            </small>
            <div className="invalid-feedback">
             {this.state.errors.pw.map( error => <div>{error}</div>)}
                        </div>
                    </div>
            <br />
            <br />
            <button type="submit" value="btn btn-primary btn-lg">Register</button>&nbsp;&nbsp;&nbsp;

            <a className="btn btn-primary btn-lg" href="/" role="button">Back</a>
            </form>
            </div>
         </div>
    );
}
}


export default Register;