import React from 'react'
function Home(props)
{
    return(
        <div>
            <h1>Welcome to shopping Cart</h1><br/>
            <a class="btn btn-primary btn-lg" href="/login" role="button">Login</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a class="btn btn-primary btn-lg" href="/register" role="button">Register</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a class="btn btn-primary btn-lg" href="/cart" role="button">Cart</a>&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
    )
}
export default Home