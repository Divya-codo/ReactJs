import React from 'react';
import Login from './components/Login'
import './App.css';
import Home from '../src/components/Home'
import Register from '../src/components/Register'
import { Route } from 'react-router-dom';
import Cart from './components/Cart';


function App() {
  return (
    <div className="App">

      <Route path="/" exact component={Home}/>
      <Route path="/login" exact component={Login}/>
      <Route path="/register" exact component={Register}/>
      <Route path="/cart" exact component={Cart}/>

    </div>
  );
}

export default App;
